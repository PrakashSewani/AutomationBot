# Join Google Meet  automatically with camera and microphone turned off

### This python script script uses Selenium to log into your gmail account at first to get all around access of google services and then joins the meeting link!

## Installation

### Navigate to the directory where you want to have this file.
### Clone this repo with ` $ git clone https://github.com/utkrixx/Google-Meet-automation-with-Python.git `
### The required packages can be installed with

> `pip install -r requirements.txt` 

### A  config.json file is used to store passwords, rather than hardcoding the password in the code.

## You should change the meeting links and time according to your needs from the  ` main.py ` file.
